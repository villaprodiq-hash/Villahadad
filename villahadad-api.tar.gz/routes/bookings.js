const express = require('express');
const pool = require('../db/pool');
const router = express.Router();

// GET /api/bookings - List all bookings
router.get('/', async (req, res, next) => {
  try {
    const result = await pool.query(
      'SELECT * FROM bookings WHERE deleted_at IS NULL ORDER BY event_date DESC'
    );
    res.json({ success: true, data: result.rows });
  } catch (error) {
    next(error);
  }
});

// POST /api/bookings - Create booking
router.post('/', async (req, res, next) => {
  try {
    const { id, client_name, client_phone, event_date, event_type, location, status, total_amount, paid_amount, details } = req.body;
    
    const result = await pool.query(
      `INSERT INTO bookings (id, client_name, client_phone, event_date, event_type, location, status, total_amount, paid_amount, details, created_at, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW(), NOW())
       RETURNING *`,
      [id, client_name, client_phone, event_date, event_type, location, status, total_amount, paid_amount, details]
    );
    
    res.status(201).json({ success: true, data: result.rows[0] });
  } catch (error) {
    next(error);
  }
});

// PUT /api/bookings/:id - Update booking
router.put('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const updates = req.body;
    
    const fields = [];
    const values = [];
    let index = 1;
    
    for (const [key, value] of Object.entries(updates)) {
      if (key !== 'id') {
        fields.push(`${key} = $${index}`);
        values.push(value);
        index++;
      }
    }
    
    if (fields.length === 0) {
      return res.status(400).json({ success: false, error: 'No fields to update' });
    }
    
    values.push(id);
    const result = await pool.query(
      `UPDATE bookings SET ${fields.join(', ')}, updated_at = NOW() WHERE id = $${index} AND deleted_at IS NULL RETURNING *`,
      values
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Booking not found' });
    }
    
    res.json({ success: true, data: result.rows[0] });
  } catch (error) {
    next(error);
  }
});

// DELETE /api/bookings/:id - Soft delete booking
router.delete('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    
    const result = await pool.query(
      'UPDATE bookings SET deleted_at = NOW() WHERE id = $1 AND deleted_at IS NULL RETURNING *',
      [id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Booking not found' });
    }
    
    res.json({ success: true, message: 'Booking deleted successfully' });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
