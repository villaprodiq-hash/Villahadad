# Villa Hadad REST API

REST API server for Villa Hadad management system.

## Installation

```bash
npm install
```

## Configuration

Create `.env` file with:

```
DB_HOST=localhost
DB_PORT=5433
DB_USER=villahadad
DB_PASS=your_password
DB_NAME=villahadad_db
PORT=3001
```

## Running Locally

```bash
npm start
```

Or with auto-reload:

```bash
npm run dev
```

## Deployment to Synology

### 1. Install Node.js on Synology

Via Package Center or SSH:

```bash
sudo apt-get install nodejs npm
```

### 2. Transfer Files

```bash
scp -r villahadad-api admin@192.168.68.107:/volume1/docker/
```

### 3. Install Dependencies on Synology

```bash
ssh admin@192.168.68.107
cd /volume1/docker/villahadad-api
npm install --production
```

### 4. Start Server

```bash
node server.js
```

### 5. Auto-Start with PM2 (Recommended)

```bash
npm install -g pm2
pm2 start server.js --name villahadad-api
pm2 save
pm2 startup
```

## API Endpoints

### Users

- `GET /api/users` - List all users
- `GET /api/users/:id` - Get user by ID
- `POST /api/users` - Create user
- `PUT /api/users/:id` - Update user
- `DELETE /api/users/:id` - Delete user

### Bookings

- `GET /api/bookings` - List all bookings
- `POST /api/bookings` - Create booking
- `PUT /api/bookings/:id` - Update booking
- `DELETE /api/bookings/:id` - Delete booking

### Health

- `GET /api/health` - Server status check
