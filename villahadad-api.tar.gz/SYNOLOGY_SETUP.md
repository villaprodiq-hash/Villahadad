# تكوين PostgreSQL على Synology للسماح بالاتصالات الخارجية

## المشكلة الحالية

PostgreSQL شغال لكن مو configured للاتصالات من خارج Synology.

## الحل - خطوات بسيطة:

### 1. افتح PostgreSQL Settings

1. افتح Synology في المتصفح: `http://192.168.68.107:5000`
2. من **Main Menu** → ابحث عن **PostgreSQL**
3. اضغط على أيقونة PostgreSQL

### 2. فعّل TCP/IP Connections

1. في نافذة PostgreSQL، روح **Settings/الإعدادات**
2. ابحث عن خيار **"Enable TCP/IP connection"**
3. فعّله ✅
4. **Port** يجب يكون: `5433`
5. اضغط **Apply/تطبيق**

### 3. سمح Access من الشبكة المحلية

في نفس Settings:

1. ابحث عن **"Trusted Host"** أو **"Allow connections from"**
2. أضف: `192.168.68.0/24` (كل الشبكة المحلية)
3. أو أضف: `0.0.0.0/0` (كل العالم - للتجربة فقط)
4. اضغط **OK/موافق**

### 4. أعد تشغيل PostgreSQL

1. في Package Center
2. اضغط **Stop** على PostgreSQL
3. انتظر 3 ثوان
4. اضغط **Run**

## بعد التطبيق - جرب مرة ثانية:

```bash
curl http://localhost:3001/api/users
```

يجب أن تشوف:

```json
{ "success": true, "data": [] }
```

---

## ملاحظات إضافية

إذا لم ينفع:

- تأكد Firewall على Synology مو blocking Port 5433
- Control Panel → Security → Firewall
- أضف rule: **Allow TCP 5433**
