const express = require('express');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(require('./middleware/cors'));

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    success: true,
    message: 'Villa Hadad API is running',
    timestamp: new Date().toISOString(),
  });
});

// Routes
app.use('/api/users', require('./routes/users'));
app.use('/api/bookings', require('./routes/bookings'));

// Error handler (must be last)
app.use(require('./middleware/errorHandler'));

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Villa Hadad API Server running on port ${PORT}`);
  console.log(`📡 Health check: http://localhost:${PORT}/api/health`);
});
